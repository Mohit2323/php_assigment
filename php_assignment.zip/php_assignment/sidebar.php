<!-- START SIDEBAR -->
      <div class="sidebar clearfix ng-scope" ng-controller="menuController">
        <ul class="sidebar-panel nav blog-nav">
          <li><a href="#" title="Leaders" class="active"><span class="icon color8">Better Assignment</span></a></li>
        </ul>
        <div class="float-right"> <a data-target="#myModal" data-toggle="modal" class="add-bnt" href="">Add New</a> </div>
      </div>